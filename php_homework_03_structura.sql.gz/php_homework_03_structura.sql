-- phpMyAdmin SQL Dump
-- version 3.5.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Oct 09, 2013 at 08:40 PM
-- Server version: 5.5.24-log
-- PHP Version: 5.4.3

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `php_homework_03`
--

-- --------------------------------------------------------

--
-- Table structure for table `groups`
--

CREATE TABLE IF NOT EXISTS `groups` (
  `groups_id` int(11) NOT NULL AUTO_INCREMENT,
  `group` varchar(50) NOT NULL,
  PRIMARY KEY (`groups_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `groups`
--

INSERT INTO `groups` (`groups_id`, `group`) VALUES(1, 'Да правя ли домашно по PHP');
INSERT INTO `groups` (`groups_id`, `group`) VALUES(2, 'Да ходя ли на лекции по PHP');
INSERT INTO `groups` (`groups_id`, `group`) VALUES(3, 'Нещо ново за изпита');
INSERT INTO `groups` (`groups_id`, `group`) VALUES(4, 'Вицове');
INSERT INTO `groups` (`groups_id`, `group`) VALUES(5, 'Сбирка на по бира');

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE IF NOT EXISTS `messages` (
  `message_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `date_published` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `group` tinyint(4) NOT NULL,
  `title` varchar(50) NOT NULL,
  `message` varchar(250) NOT NULL,
  PRIMARY KEY (`message_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `rights`
--

CREATE TABLE IF NOT EXISTS `rights` (
  `rights_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `read` tinyint(1) NOT NULL,
  `write` tinyint(1) NOT NULL,
  `edit` tinyint(1) NOT NULL,
  `erase` tinyint(1) NOT NULL,
  `admin` tinyint(1) NOT NULL,
  PRIMARY KEY (`rights_id`),
  KEY `admin` (`admin`),
  KEY `admin_2` (`admin`),
  KEY `admin_3` (`admin`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `rights`
--

INSERT INTO `rights` (`rights_id`, `name`, `read`, `write`, `edit`, `erase`, `admin`) VALUES(1, 'Писател', 1, 1, 0, 0, 0);
INSERT INTO `rights` (`rights_id`, `name`, `read`, `write`, `edit`, `erase`, `admin`) VALUES(2, 'Шеф', 1, 1, 1, 1, 1);
INSERT INTO `rights` (`rights_id`, `name`, `read`, `write`, `edit`, `erase`, `admin`) VALUES(3, 'Читател', 1, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL,
  `nickname` varchar(20) NOT NULL,
  `firstname` varchar(20) NOT NULL,
  `lastname` varchar(20) NOT NULL,
  `email` varchar(50) NOT NULL,
  `date_registered` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `rights` tinyint(4) NOT NULL DEFAULT '1',
  PRIMARY KEY (`user_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `username`, `password`, `nickname`, `firstname`, `lastname`, `email`, `date_registered`, `rights`) VALUES(3, 'admin', 'qwerty', 'Administrator', 'Големия', 'Шеф', 'admin@admin.com', '2013-10-07 18:00:31', 2);
INSERT INTO `users` (`user_id`, `username`, `password`, `nickname`, `firstname`, `lastname`, `email`, `date_registered`, `rights`) VALUES(4, 'usera', '123456', 'usera', '', '', 'user@user.com', '2013-10-09 20:01:15', 1);
INSERT INTO `users` (`user_id`, `username`, `password`, `nickname`, `firstname`, `lastname`, `email`, `date_registered`, `rights`) VALUES(5, 'qwerty', 'qwerty', 'qwerty', '', '', 'qwerty@user.com', '2013-10-09 20:08:23', 1);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
